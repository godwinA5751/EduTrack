import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/layout/Header";
import ProfileSkeleton from "../components/ui/ProfileSkeleton";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getProfile } from "../queries/profileQueries";
import { calculateProfileStats } from "../services/academic";

export default function Profile() {
  const navigate = useNavigate();

  const queryClient = useQueryClient();
const currentUser = queryClient.getQueryData(["current-user"]);
const userId = currentUser?.id ?? null;

const { data, isLoading, error } = useQuery({
  queryKey: ["profile", userId],
  queryFn: getProfile,
  enabled: Boolean(userId),
});

  const profile = data?.profile ?? null;
  const academic = data?.levels ?? [];

  useEffect(() => {
    if (!isLoading && !profile) {
      navigate("/login");
    }
  }, [isLoading, profile, navigate]);

  // ✅ Use carryover-aware calculation for stats
  const stats = calculateProfileStats(academic);

  const currentLevel =
    academic.length > 0
      ? Math.max(...academic.map((l) => l.level))
      : "Not Started";

  if (isLoading) {
    return (
      <div>
        <Header title="Profile" subtitle="Your academic summary" className="mb-20" />
        <ProfileSkeleton />
      </div>
    );
  }
  if (!profile) return error ? <p>Error: {error.message}</p> : <p>No profile data available.</p>;

  const initial = profile.full_name?.charAt(0) || "?";

  const degreeClass =
    stats.cgpa < 1
      ? "Fail"
      : stats.cgpa < 1.5
        ? "Pass"
        : stats.cgpa < 2.5
          ? "Third Class"
          : stats.cgpa < 3.5
            ? "2:2"
            : stats.cgpa < 4.5
              ? "2:1"
              : stats.cgpa <= 5
                ? "First Class"
                : "Nil";

  return (
    <div className="
      bg-linear-to-br 
      from-[#A5D1E1] via-[#199FB1] to-[#0D5C75]
      dark:from-[#0B1F2A] dark:via-[#0F3A47] dark:to-[#021A22] min-h-screen overflow-hidden">
      <Header title="Profile" subtitle="Your academic summary" />

        <div className="px-6 h-[calc(100vh-70px)] overflow-y-auto scrollbar-hide scroll-smooth">
          <div className="max-w-3xl mx-auto mt-40 lg:my-50 md:mt-45 bg-white/20 dark:bg-white/5 backdrop-blur-md rounded-3xl p-8 shadow-lg flex flex-col gap-6">
            {/* Avatar */}
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-full bg-[#A7EBF2]/50 dark:bg-[#0B1F2A] flex items-center justify-center text-3xl font-bold text-white">
                {initial}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  {profile.full_name}
                </h2>
                <p className="text-white/80">{profile.matric_no}</p>
              </div>
            </div>
  
            {/* Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <Stat label="Current Level" value={currentLevel} />
              <Stat label="Cumulative GPA" value={stats.cgpa.toFixed(2)} />
              <Stat label="Levels" value={stats.levels} />
              <Stat label="Semesters" value={stats.semesters} />
              <Stat label="Total Units" value={stats.units} />
              <Stat label="Total Points" value={stats.points} />
              <Stat label="Class" value={degreeClass} />
            </div>
          </div>
        </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="flex flex-col">
      <span className="text-white/70 text-sm">{label}</span>
      <span className="text-white font-semibold">{value}</span>
    </div>
  );
}