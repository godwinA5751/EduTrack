import { supabase } from "../lib/supabaseClient";

export async function getCurrentUser() {
  const {
    data: { session },
    error: sessionError,
  } = await supabase.auth.getSession();

  console.log("Offline auth check:", {
    hasSession: Boolean(session),
    userId: session?.user?.id ?? null,
    sessionError: sessionError?.message ?? null,
    online: navigator.onLine,
  });

  if (!session) return null;

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", session.user.id)
    .single();

  if (error) {
    console.log("Profile fetch error:", error.message);
    throw error;
  }

  return profile;
}