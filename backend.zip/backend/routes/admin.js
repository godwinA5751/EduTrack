import { Router } from "express";
import { createClient } from "@supabase/supabase-js";
import { supabase } from "../supabase.js";
import { verifyAdmin } from "../middleware/auth.js";
import { generateTempPassword } from "../utils/password.js";
import adminCache from "../cache/adminCache.js";
import { getAdminUsers } from "../services/adminService.js";
import { CacheKeys } from "../cache/cacheKey.js";

const router = Router();
router.use(verifyAdmin);

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

router.get("/users", async (req, res) => {
  try {
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.max(parseInt(req.query.limit) || 10, 1);
    const search = (req.query.search ?? "").trim().toLowerCase();;
    const role = req.query.role || "all";
    
    const cacheKey = CacheKeys.users({
      page,
      limit,
      role,
      search,
    });
    
    const cached = adminCache.get(cacheKey);
    
    if (cached) {
        return res.json(cached);
    }
    
    const response = await getAdminUsers({
        page,
        limit,
        search,
        role,
    });
    
    adminCache.set(cacheKey, response);
    
    return res.json(response);
    
  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
});

router.post("/reset-password", async (req, res) => {
  try {
    const { profileId } = req.body;

    if (!profileId || typeof profileId !== "string") {
      return res.status(400).json({
        success: false,
        message: "Invalid profile ID",
      });
    }

    // Ensure the profile exists
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("id, full_name, matric_no, role")
      .eq("id", profileId)
      .single();

    if (profileError || !profile) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    if (profile.role === "admin") {
      return res.status(403).json({
        success: false,
        message: "Admin passwords cannot be reset.",
      });
    }

    const temporaryPassword = generateTempPassword();

    // Update Supabase Auth password
    const { error: authError } =
      await supabaseAdmin.auth.admin.updateUserById(profileId, {
        password: temporaryPassword,
      });

    if (authError) {
      if (authError.code === "user_not_found") {
        return res.status(404).json({
          success: false,
          message: "This user no longer exists in the authentication system.",
        });
      }
    
      throw authError;
    }

    // Require password change
    const { error: updateError } = await supabase
      .from("profiles")
      .update({
        must_change_password: true,
      })
      .eq("id", profileId);

    if (updateError) throw updateError;
    adminCache.flushAll();

    return res.status(200).json({
      success: true,
      message: "Password reset successfully",
      temporaryPassword,
    });

  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message,
    });
  }
});

router.delete("/users/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Prevent deleting yourself
    if (req.user.id === id) {
      return res.status(400).json({
        success: false,
        message: "You cannot delete your own account.",
      });
    }

    // Check profile exists
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", id)
      .single();

    if (profileError || !profile) {
      return res.status(404).json({
        success: false,
        message: "User not found.",
      });
    }

    // Delete from Supabase Auth
    const { error: authError } =
      await supabaseAdmin.auth.admin.deleteUser(id);

    // Ignore if auth user is already missing
    if (authError && authError.code !== "user_not_found") {
      throw authError;
    }

    // Delete profile
    const { error: deleteError } = await supabase
      .from("profiles")
      .delete()
      .eq("id", id);

    if (deleteError) {
      throw deleteError;
    }
    adminCache.flushAll();

    return res.json({
      success: true,
      message: "User deleted successfully.",
    });

  } catch (err) {
    console.error(err);

    return res.status(500).json({
      success: false,
      message: err.message || "Failed to delete user.",
    });
  }
});

export default router;